
<?php
// on se connecte à notre base
session_start();
try
    {
        include ('BDD.php');
    }
    catch(Exception $e)
    {
        die('Erreur : '.$e->getMessage());
    }
if(isset($_REQUEST['submit'])){	
 $produit_nom=$_POST["Produit_nom"];
 $prix=$_POST['Prix'];
 $description=$_POST['Description'];
 
 $sql ="UPDATE produit SET Prix='$prix', DESCRIPTION='$description'WHERE PRODUIT_NOM='$produit_nom'";

 $requete = mysqli_query($mysqli,$sql) or die(mysqli_error($mysqli));
	 if($requete)
  {
    echo("modification effectuée") ;
  }
  else
  {
    echo("L'insertion à échouée") ;
  }

	

	
}
	

?>