
<html>
    
 <?php
/*
Page: connexion.php
*/
session_start(); ?>

<!DOCTYPE html>
    <html>
         <head>
		<title>First.com</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1" />
		<link rel="stylesheet" href="assets/css/main.css" />
	</head>
        
        
    <body>
     
     <header id="header" class="alt">
				<div class="logo"><a href="index.php">First</a></div>
				<a href="#menu">Menu</a>
			</header>
            
    <nav id="menu">
				<ul class="links">
					
                    <li><a href="commercial.php">Acceuil commercial</a></li>
				</ul>
        <ul>
            <li><a href="index.php">Déconnexion</a></li>
        </ul>
			</nav>    
            
      <section id="One" class="wrapper style3">
				<div class="inner">
					<header class="align-center">
						<h2>Liste des devis</h2>
					</header>
				</div>
			</section>
         <?php
        // session_login.php

        /* inclusion de la fonction connectMySQL() */
        require_once("connectMySql.inc.php"); // connection a la basse de donnée
        try {
            $conn = connectMySQL();
            $stmt = $conn->query('SELECT * FROM devis');
            session_start();
        ?>
    <div class="row">    
     <nav class="navbar navbar-expand-md navbar-dark fixed-top bg-dark" data-spy="affix">
         <button class="navbar-toggler d-lg-none" type="button" data-toggle="collapse" data-target="#navbarsExampleDefault" aria-controls="navbarsExampleDefault" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button> 

        <div class="collapse navbar-collapse" id="navbarsExampleDefault">
            
           
            
     
        </div>
     </nav>
    </div>
    <style>
        img{
           width: 50px;
           height: 50px; 
        }
    </style>
        

                    <h4>Liste des devis </h4>

        <fieldset> <!-- cadre -->
                                    <legend><br/></legend>
                                    <div class="row">
                                        <div class="col-12 col-md-12 col-lg-12">
                                            <table class="table">
                                                <thead>
                                                    <tr>

                                                        <th>Devis ID</th>
                                                        <th>Client ID</th>
                                                        <th>Produit</th>
                                                        <th>Quantités</th>
                                                        <th>Prix</th>
                                                        <th>Commentaires</th>
                                                        


                                                    </tr>

                                                </thead>
                                                <tbody>

                                                     <?php $i=1;
                                                    while($donnees = $stmt->fetch())
                                                    {

                                                   ?>
                                                    <tr>
                                                        

                                                        <td><?php echo $donnees['DEVIS_ID'];?></td>
                                                        <td><?php echo $donnees['CLIENT_ID'];?></td>
                                                        <td><?php echo $donnees['PRODUIT_ID'];?></td>
                                                        <td><?php echo $donnees['QUANTITE'];?></td>
                                                        <td><?php echo $donnees['PRIX'];?></td>
                                                        <td><?php echo $donnees['COMMENTAIRES'];?></td>

                                                    </tr>
                                                    <?php
                                                        $i=$i +1;
                                                    } //fin de la boucle, le tableau contient toute la
                                                    ?>

                                                </tbody>
                                            </table>
                                        </div>
            </div>
            </fieldset>
         <?php $conn = null;
} catch (PDOException $e) {
    print "Erreur !: " . $e->getMessage() . "<br/>";
    echo $e->getTraceAsString();
    die();
}?>
        <?php include 'basdepage.inc.php';?>
         <script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/jquery.scrollex.min.js"></script>
			<script src="assets/js/skel.min.js"></script>
			<script src="assets/js/util.js"></script>
			<script src="assets/js/main.js"></script>
    
  </body>
</html>
