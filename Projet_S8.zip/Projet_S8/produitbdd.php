<?php
    session_start();
try
    {
        include ('BDD.php');
    }
    catch(Exception $e)
    {
        die('Erreur : '.$e->getMessage());
    }
    
    if(isset($_REQUEST['submit'])){
        $produit_nom=$_REQUEST['Produit_nom'];
        $categorie=$_POST['Categories'];
        $images=$_REQUEST['Images'];
        $prix=$_REQUEST['Prix'];
        $description=$_REQUEST['Description'];
        
        
    
    
    $sql = "INSERT INTO produit( PRODUIT_NOM, CATEGORIE, IMAGES, Prix, DESCRIPTION) VALUES('$produit_nom','$categorie', '$images','$prix', '$description')";
    
    
    mysqli_query($mysqli,$sql) or die(mysqli_error($mysqli));
    
    header( "refresh:0;url=afficherproduit.php" );
    echo 'Produit créé avec succès!';
    
    
    
    
    }
?>