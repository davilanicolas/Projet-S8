<?php
    session_start();
try
    {
        include ('BDD.php');
    }
    catch(Exception $e)
    {
        die('Erreur : '.$e->getMessage());
    }
    
    if(isset($_REQUEST['submit'])){
       
        $images=$_REQUEST['Images'];
        
        
        
    
    
    $sql = "INSERT INTO image(IMAGES) VALUES('$images')";
    
    
    mysqli_query($mysqli,$sql) or die(mysqli_error($mysqli));
    
    
    echo 'Produit créé avec succès!';
    header( "refresh:0;url=afficherproduit.php" );
    
    
    
    }
?>
	

	
