<?php
    session_start();
try
    {
        include ('BDD.php');
    }
    catch(Exception $e)
    {
        die('Erreur : '.$e->getMessage());
    }
    
    if(isset($_REQUEST['submit'])){
        $client_nom=$_REQUEST['Client_nom'];
        $client_prenom=$_REQUEST['Client_prenom'];
        $adresse=$_REQUEST['Adresse'];
        $telephone=$_REQUEST['Telephone'];
        
    
    
    $sql = "INSERT INTO client( CLIENT_NOM, CLIENT_PRENOM, ADRESSE, TELEPHONE) VALUES('$client_nom','$client_prenom','$adresse','$telephone')";
    
    
    mysqli_query($mysqli,$sql) or die(mysqli_error($mysqli));
    
    
    echo 'Client créé avec succès!';
    header( "refresh:0;url=commercial.php" );
    
    
    
    }
?>