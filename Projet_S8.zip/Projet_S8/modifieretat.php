<!DOCTYPE html>

<html>
    
    <?php include 'HautDePage.inc.php'?>
    <body>
    <div class="row">    
     <nav class="navbar navbar-expand-md navbar-dark fixed-top bg-dark" data-spy="affix">
         <button class="navbar-toggler d-lg-none" type="button" data-toggle="collapse" data-target="#navbarsExampleDefault" aria-controls="navbarsExampleDefault" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button> 

        <div class="collapse navbar-collapse" id="navbarsExampleDefault">
            
            
            
 <?php include 'divhautdepage.inc.php';?>      
            
        <div class="navbar-collapse collapse w-100 order-3 dual-collapse2">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item">
                    <a class="nav-link" href="employe.php">Liste des Commandes <span class="sr-only">(current)</span></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="index.php">Déconnexion <span class="sr-only">(current)</span></a>
                </li>
            </ul>
        </div>
            
        </div>
     </nav>
    </div> 
        
       <div class="container"> <!-- Conteneur 1 -->
            <div class="row">
                
                <div class="col-sm-6">

                    
                    <form action="changeretat.php" method="post"> <!-- cadre -->
                        <h1>Changer Etat commande</h1>

                        
<label class="col-sm-4" for="">Commande ID   </label>
                        <select class="form-control col-sm-5 " type="text" name="Commande_id">
                                    
                                    <?php

                                         require_once("./connectMySql.inc.php");
//pour verifier et si il n'est pas déja placé dans cette matière
try {
    $conn = connectMySQL();

                                         $stmt20 = $conn->query('SELECT * FROM commande');

                                        while($donnees = $stmt20->fetch())
                                            {?>
                                                 <option name=Commande_id value="<?php echo $donnees['COMMANDE_ID']?>"><?php echo $donnees['COMMANDE_ID']?></option>

                                             <?php }

                                           $conn = null;
    } catch (PDOException $e) {
        print "Erreur !: " . $e->getMessage() . "<br/>";
        echo $e->getTraceAsString();
        die();
    }?>

                                </select><br/>
                        
                        <label class="col-sm-4" for="Etat">Catégorie du produit   </label>
                        <select class="form-control col-sm-5 " type="text" name="Etat" required>
                                
                                    <option value="fait">fait</option>
                                    <option value="non fait">non fait</option>
                                    
                                </select><br/>
                    

                        <button  name="submit" type="submit" style="color:blue; font-weight:black"onclick>Modifier</button>
                        <br/><br/>
                    </form>
                </div>

           </div>
           
        </div>
        
    </body>
</html>