<?php
// on se connecte à notre base
session_start();
try
    {
        include ('BDD.php');
    }
    catch(Exception $e)
    {
        die('Erreur : '.$e->getMessage());
    }
 $commande_id=$_POST["Commande_id"];
 $etat=$_POST["Etat"];
 $sql ="UPDATE commande SET ETAT='$etat' WHERE Commande_id='$commande_id'";

	
 $requete = mysqli_query($mysqli,$sql) or die(mysqli_error($mysqli));
	 if($requete)
  {
    echo("Changement effectué") ;
  }
  else
  {
    echo("L'insertion à échouée") ;
  }

	

	

	

?>