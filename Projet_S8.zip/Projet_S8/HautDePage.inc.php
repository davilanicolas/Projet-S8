<head>
            <title>First.com</title>
            <meta charset="utf-8">
            <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

            <!-- Bootstrap CSS "navbar-brand" href="#">Soutenance -->
            <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/css/bootstrap.min.css" integrity="sha384-PsH8R72JQ3SOdhVi3uxftmaW6Vc51MKb0q5P2rRUpPvrszuE4W1povHYgTpBfshb" crossorigin="anonymous">
            <!-- Custom styles for this template -->
            <style>
            /* Remove the navbar's default margin-bottom and rounded borders */ 
            .navbar {
              margin-bottom: 0;
              border-radius: 0;
                }

            /* Add a gray background color and some padding to the footer */
            footer {
              background-color: #f2f2f2;
              padding: 25px;
            }

            .carousel-inner img {
              width: 100%; /* Set width to 100% */
              margin: auto;
              min-height:200px;
            }
                
                .pht {
                    height: 768px;
                    width: 1024px;
                }
                body, h2 {
                    padding-top: 90px;
                }
            
            /* Hide the carousel text when the screen is less than 600 pixels wide */
            @media (max-width: 600px) {
            .carousel-caption {
              display: none; 
                }
            }
          </style>
        </head>

