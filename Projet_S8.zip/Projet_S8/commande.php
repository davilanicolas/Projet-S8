
<html>
    
 <?php
/*
Page: connexion.php
*/
session_start(); ?>

<!DOCTYPE html>
    <html>
         <head>
		<title>First.com</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1" />
		<link rel="stylesheet" href="assets/css/main.css" />
	</head>
        
        
    <body>
     
     <header id="header" class="alt">
				<div class="logo"><a href="index.php">First</a></div>
				<a href="#menu">Menu</a>
			</header>
            
    <nav id="menu">
				<ul class="links">
					
                    <li><a href="commercial.php">Acceuil commercial</a></li>
				</ul>
        <ul>
            <li><a href="index.php">Déconnexion</a></li>
        </ul>
			</nav>    
            
      <section id="One" class="wrapper style3">
				<div class="inner">
					<header class="align-center">
						<h2>Liste des commandes</h2>
					</header>
				</div>
			</section>
        <style>
        img{
           width: 50px;
           height: 50px; 
        }
    </style>

                    <h4>Liste des commandes</h4>

        <div class="table-responsive">
            <table class="table table-striped">
              <thead>
                                                    <tr>
                                                      

                                                        <th>Produit</th>
                                                        <th>Categorie</th>
                                                        <th>Quantité</th>
                                                        <th>Images</th>
                                                        <th>Client</th>
                                                        <th>Adresse</th>
                                                        <th>Telephone</th>
                                                        <th>Etat</th>
                                                       
                                                        


                                                    </tr>

                                                </thead>
              <tbody>
                
               <?php  $mysqli=mysqli_connect("localhost", "root", "root","sitevitrine"); // Connexion à MySQL
               
                $sql="SELECT commande.QUANTITE, client.ADRESSE, client.CLIENT_NOM, client.CLIENT_PRENOM, client.TELEPHONE, produit.PRODUIT_NOM, produit.CATEGORIE, produit.IMAGES, commande.ETAT
                      FROM ((commande
                      INNER JOIN client ON commande.CLIENT_ID = client.CLIENT_ID)
                      INNER JOIN produit ON commande.PRODUIT_ID = produit.PRODUIT_ID)";
            
                $req = mysqli_query($mysqli,$sql) or die(mysqli_error($mysqli));?> 
            
            
               <?php while($donnees = mysqli_fetch_assoc($req))
                { ?>
                
                <tr>
                  <td><?php echo $donnees['PRODUIT_NOM'];?></td>
                  <td><?php echo $donnees['CATEGORIE'];?></td>
                  <td><?php echo $donnees['QUANTITE'];?></td>
                  <td><img src="<?php echo $donnees['IMAGES'];?>"/></td>
                  <td><?php echo $donnees['CLIENT_NOM'];?> <?php echo $donnees['CLIENT_PRENOM'];?></td>
                  <td><?php echo $donnees['ADRESSE'];?></td>
                  <td><?php echo $donnees['TELEPHONE'];?></td>
                  <td><?php echo $donnees['ETAT'];?></td>
                  
                 </tr>
                
                <?php }
                
                
            mysqli_free_result($req);
            mysqli_close($mysqli);   
?>
                
                
              </tbody>
                                            </table>
                                        </div>
        <?php include 'basdepage.inc.php';?>
               <script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/jquery.scrollex.min.js"></script>
			<script src="assets/js/skel.min.js"></script>
			<script src="assets/js/util.js"></script>
			<script src="assets/js/main.js"></script>
  </body>
</html>
