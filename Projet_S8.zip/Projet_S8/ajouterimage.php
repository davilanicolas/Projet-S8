 <!DOCTYPE html>

<html>
    <head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8" /></head>
    <?php include 'HautDePage.inc.php'?>
    <body>
    <div class="row">    
     <nav class="navbar navbar-expand-md navbar-dark fixed-top bg-dark" data-spy="affix">
         <button class="navbar-toggler d-lg-none" type="button" data-toggle="collapse" data-target="#navbarsExampleDefault" aria-controls="navbarsExampleDefault" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button> 

        <div class="collapse navbar-collapse" id="navbarsExampleDefault">
            
           
            
<?php include 'divhautdepage.inc.php';?>    
            
        <div class="navbar-collapse collapse w-100 order-3 dual-collapse2">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item">
                    <a class="nav-link" href="afficherproduit.php">Afficher Produit <span class="sr-only">(current)</span></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="index.php">Déconnexion <span class="sr-only">(current)</span></a>
                </li>
            </ul>
        </div>
            
        </div>
     </nav>
    </div> 
<form action="ajouter.php" method="post"> <!-- cadre -->
                        <h1>ajouter image</h1>
        
 <label class="col-sm-4" for="">Images  </label>
                        <input class="form-control col-sm-5 " type="file" name="Images" placeholder="Prix " required><br/>
    <button  name="submit" type="submit" style="color:blue; font-weight:black"onclick>Ajouter</button>
                        
                        <br/><br/>
                    </form>
                        
                         </body>
</html>