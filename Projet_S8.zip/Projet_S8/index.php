<?php
/*
Page: connexion.php
*/
session_start(); ?>
<!DOCTYPE HTML>

<html>
	<head>
		<title>First.com</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1" />
		<link rel="stylesheet" href="assets/css/main.css" />
	</head>
	<body>

		<!-- Header -->
			<header id="header" class="alt">
				<div class="logo"><a href="index.php">First</a></div>
				<a href="#menu">Menu</a>
			</header>

		<!-- Nav -->
			<nav id="menu">
				<ul class="links">
					              <?php

                                         require_once("./connectMySql.inc.php");
//pour verifier et si il n'est pas déja placé dans cette matière
try {
    $conn = connectMySQL();

                                         $stmt20 = $conn->query('SELECT * FROM categories ');

                                        while($donnees = $stmt20->fetch())
                                            {?>
                <li class="nav-item">
                                                 <a href="categories.php?id=<?php echo $donnees['CATEGORIES']?>"><?php echo $donnees['CATEGORIES']?></a>
                    
            </li>

                                             <?php }
    
                                           $conn = null;
    } catch (PDOException $e) {
        print "Erreur !: " . $e->getMessage() . "<br/>";
        echo $e->getTraceAsString();
        die();
    }?>
                

                              
                
				</ul>
                <ul class="links">
                <li class="nav-item">
                    <a href="connexion.php">Connexion</a>
                    <a href="inscription.php">Inscripton</a>
                    </li>
                </ul>
			</nav>

		<!-- Banner -->
			<section class="banner full">
				<article>
					<img src="images/Vetements/tshirtdbz.jpg" alt="" />
					<div class="inner">
						<header>
							<p>Un t-shirt dragon ball Z</p>
							
						</header>
					</div>
				</article>
				<article>
					<img src="images/Figurines/batman.jpg" alt="" />
					<div class="inner">
						<header>
							<p>Une figurine Batman</p>
							
						</header>
					</div>
				</article>
				<article>
					<img src="images/JeuxVideo/fortnite.jpg"  alt="" />
					<div class="inner">
						<header>
							<p>Le jeux vidéo Fortnite</p>
							
						</header>
					</div>
				</article>
				
				
			</section>

		<!-- One -->
			<section id="one" class="wrapper style2">
				<div class="inner">
                    <p>Dernière nouveautées</p>
					<div class="grid-style">

						<div>
							<div class="box">
								<div class="image fit">
									<img src="images/Figurines/fortnite.jpg" alt="" />
								</div>
							
							</div>
						</div>

						<div>
							<div class="box">
								<div class="image fit">
									<img src="images/JeuxVideo/dragonballz.jpg" alt="" />
								</div>
							
							</div>
						</div>

					</div>
				</div>
			</section>

		

		


		<!-- Footer -->
		<?php include 'basdepage.inc.php';?>

		<!-- Scripts -->
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/jquery.scrollex.min.js"></script>
			<script src="assets/js/skel.min.js"></script>
			<script src="assets/js/util.js"></script>
			<script src="assets/js/main.js"></script>

	</body>
</html>