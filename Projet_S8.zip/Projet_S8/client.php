<!DOCTYPE html>

<html>
    
 <?php
/*
Page: connexion.php
*/
session_start(); ?>

<!DOCTYPE html>
    <html>
         <head>
		<title>First.com</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1" />
		<link rel="stylesheet" href="assets/css/main.css" />
	</head>
        
        
    <body>
     
     <header id="header" class="alt">
				<div class="logo"><a href="index.php">First</a></div>
				<a href="#menu">Menu</a>
			</header>
            
    <nav id="menu">
				<ul class="links">
					<li><a href="listeclient.php">Liste des clients</a></li>
                    <li><a href="commercial.php">Acceuil commercial</a></li>
				</ul>
        <ul>
            <li><a href="index.php">Déconnexion</a></li>
        </ul>
			</nav>    
            
      <section id="One" class="wrapper style3">
				<div class="inner">
					<header class="align-center">
						<h2>Création d'un client</h2>
					</header>
				</div>
			</section>
        
        
       <section id="one" class="wrapper style2">
				<div class="inner">
					<div class="grid-style">

						<div>
							<div class="box">
								
								<div class="content">
									  <form action="clientbdd.php" method="post"> <!-- cadre -->
                        <h1>Créer Client</h1>

                        <label class="col-sm-4" for="">Nom du client   </label>
                        <input class="form-control col-sm-5 " type="text" name="Client_nom" placeholder="nom du client " required><br/>

                        <label class="col-sm-4" for="Client">Prénom du client   </label>
                        <input class="form-control col-sm-5 " type="text" name="Client_prenom" placeholder="prenom du client " required><br/>
                        
                        <label class="col-sm-4" for="">Adresse  </label>
                        <input class="form-control col-sm-5 " type="text" name="Adresse" placeholder="Adresse" required><br/>
                        
                        <label class="col-sm-4" for="">Telephone   </label>
                        <input class="form-control col-sm-5 " type="text" name="Telephone" placeholder="Telephone" required><br/>
            
                        


                        <button  name="submit" type="submit" style="color:blue; font-weight:black"onclick>créer le client</button>
                        <br/><br/>
                    </form>
									
									
								</div>
							</div>
						</div>

					

					</div>
				</div>
			</section>
        <?php include 'basdepage.inc.php';?>
                
                <script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/jquery.scrollex.min.js"></script>
			<script src="assets/js/skel.min.js"></script>
			<script src="assets/js/util.js"></script>
			<script src="assets/js/main.js"></script>
    </body>
</html>