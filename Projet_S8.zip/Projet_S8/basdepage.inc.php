	<footer id="footer">
        <h2>Contact</h2>
        <div>
        Une question ? Contactez nous par téléphone au (+33) 2 35 68 45 45 ou par mail first@gmail.com
        </div>
				<div class="container">
					<ul class="icons">
						<li><a href="https://twitter.com/?lang=fr" class="icon fa-twitter"><span class="label">Twitter</span></a></li>
						<li><a href="https://www.facebook.com/" class="icon fa-facebook"><span class="label">Facebook</span></a></li>
						<li><a href="https://www.instagram.com/?hl=fr" class="icon fa-instagram"><span class="label">Instagram</span></a></li>
						<li><a href="https://outlook.live.com/owa/" class="icon fa-envelope-o"><span class="label">Email</span></a></li>
					</ul>
				</div>
				
			</footer>