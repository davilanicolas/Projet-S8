<?php
// on se connecte à notre base
session_start();
try
    {
        include ('BDD.php');
    }
    catch(Exception $e)
    {
        die('Erreur : '.$e->getMessage());
    }
 $produit_nom=$_POST["Produit_nom"];
 $sql ="DELETE from produit WHERE PRODUIT_NOM='$produit_nom'";
	
 $requete = mysqli_query($mysqli,$sql) or die(mysqli_error($mysqli));
	 if($requete)
  {
    echo("Supression effectuée") ;
  }
  else
  {
    echo("L'insertion à échouée") ;
  }

	

	

	

?>