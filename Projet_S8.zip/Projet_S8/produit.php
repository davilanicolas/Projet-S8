<!DOCTYPE html>

<html>
    
 <?php
/*
Page: connexion.php
*/
session_start(); ?>

<!DOCTYPE html>
    <html>
         <head>
		<title>First.com</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1" />
		<link rel="stylesheet" href="assets/css/main.css" />
	</head>
        
        
    <body>
     
     <header id="header" class="alt">
				<div class="logo"><a href="index.php">First</a></div>
				<a href="#menu">Menu</a>
			</header>
            
    <nav id="menu">
				<ul class="links">
					<li><a href="afficherproduit.php">Afficher Produit</a></li>
                    <li><a href="commercial.php">Acceuil commercial</a></li>
				</ul>
        <ul>
            <li><a href="index.php">Déconnexion</a></li>
        </ul>
			</nav>    
            
      <section id="One" class="wrapper style3">
				<div class="inner">
					<header class="align-center">
						<h2>Produit</h2>
					</header>
				</div>
			</section>
        
      <section id="one" class="wrapper style2">
				<div class="inner">
					<div class="grid-style">

						<div>
							<div class="box">
								
								<div class="content">
									            <form action="produitbdd.php" method="post"> <!-- cadre -->
                        <h1>Créer Produit</h1>

                        <label class="col-sm-4" for="">Nom du produit   </label>
                        <input class="form-control col-sm-5 " <?php if ($erreur_feedback){echo isset($_SESSION['nom_erreur'])? 'is-invalid' : 'is-valid' ; }?> type="text" name="Produit_nom" placeholder="nom du produit " required><br/>
                        <?php if (isset($_SESSION['nom_erreur'])){
    echo '<div class="col-sm-4"></div><div class="col-sm-8 invalid-feedback">'.$_SESSION['nom_erreur'].'</div>';
    unset($_SESSION['nom_erreur']);}
                    ?>

                        <label class="col-sm-4" for="Client">Catégorie du produit   </label>
                        <select class="form-control col-sm-5 " type="text" name="Categories">
                                    
                                    <?php

                                         require_once("./connectMySql.inc.php");
//pour verifier et si il n'est pas déja placé dans cette matière
try {
    $conn = connectMySQL();

                                         $stmt20 = $conn->query('SELECT CATEGORIES FROM categories');

                                        while($donnees = $stmt20->fetch())
                                            {?>
                                                 <option name=Categories value="<?php echo $donnees['CATEGORIES']?>"><?php echo $donnees['CATEGORIES']?></option>

                                             <?php }

                                           $conn = null;
    } catch (PDOException $e) {
        print "Erreur !: " . $e->getMessage() . "<br/>";
        echo $e->getTraceAsString();
        die();
    }?>

                                </select><br/>
                        
                        <label class="col-sm-4" for="">Images  </label>
                        
                        <input class="form-control col-sm-5 " type="text" name="Images" placeholder="Image " required><br/>
                        <img src="<?php echo $donnees['IMAGES'];?>"/>
                        
                        <label class="col-sm-4" for="">Prix  </label>
                        <input class="form-control col-sm-5 " type="text" name="Prix" placeholder="Prix " required><br/>
                        
                        <label class="col-sm-4" for="">Description  </label>
                        <input class="form-control col-sm-5 " type="text" name="Description" placeholder=" Description " required><br/>
                        
                    
                        
                        
            
                        


                        <button  name="submit" type="submit" style="color:blue; font-weight:black"onclick>créer le produit</button>
                        <br/><br/>
                    </form>
								</div>
							</div>
						</div>

						<div>
							<div class="box">
								
								<div class="content">
									<form action="modifproduitbdd.php" method="post"> <!-- cadre -->
                        <h1>Modifier Produit</h1>

                        <label class="col-sm-4" for="">Nom du produit   </label>
                        <select class="form-control col-sm-5 " type="text" name="Produit_nom">
                                    
                                    <?php

                                         require_once("./connectMySql.inc.php");
//pour verifier et si il n'est pas déja placé dans cette matière
try {
    $conn = connectMySQL();

                                         $stmt20 = $conn->query('SELECT Prix,DESCRIPTION, PRODUIT_NOM FROM produit');

                                        while($donnees = $stmt20->fetch())
                                            {?>
                                                 <option name=Produit_nom value="<?php echo $donnees['PRODUIT_NOM']?>"><?php echo $donnees['PRODUIT_NOM']?></option>

                                             <?php }

                                           $conn = null;
    } catch (PDOException $e) {
        print "Erreur !: " . $e->getMessage() . "<br/>";
        echo $e->getTraceAsString();
        die();
    }?>

                                </select><br/>
                        
                        
                        <label class="col-sm-4" for="">Prix  </label>
                        <input class="form-control col-sm-5 " type="text" name="Prix" placeholder="Prix " required><br/>
                        
                        <label class="col-sm-4" for="">Description  </label>
                        <input class="form-control col-sm-5 " type="text" name="Description" placeholder=" Description " required><br/>
                        
                        
            
                        


                        <button  name="submit" type="submit" style="color:blue; font-weight:black"onclick>Modifier</button>
                        <br/><br/>
                    </form>

								</div>
							</div>
						</div>
                        <div>
							<div class="box">
								
								<div class="content">
									<form action="supprimer.php" method="post"> <!-- cadre -->
                        <h1>Supprimer Produit</h1>

                        
<label class="col-sm-4" for="">Nom du produit   </label>
                        <select class="form-control col-sm-5 " type="text" name="Produit_nom">
                                    
                                    <?php

                                         require_once("./connectMySql.inc.php");
//pour verifier et si il n'est pas déja placé dans cette matière
try {
    $conn = connectMySQL();

                                         $stmt20 = $conn->query('SELECT * FROM produit');

                                        while($donnees = $stmt20->fetch())
                                            {?>
                                                 <option name=Produit_nom value="<?php echo $donnees['PRODUIT_NOM']?>"><?php echo $donnees['PRODUIT_NOM']?></option>

                                             <?php }

                                           $conn = null;
    } catch (PDOException $e) {
        print "Erreur !: " . $e->getMessage() . "<br/>";
        echo $e->getTraceAsString();
        die();
    }?>

                                </select><br/>
                    

                        <button  name="submit" type="submit" style="color:blue; font-weight:black" onclick="return(confirm('Etes-vous sûr de vouloir supprimer ce Produit'));">supprimé le produit</button>
                        
                        <br/><br/>
                    </form>
								</div>
							</div>
						</div>
                         <div>
							<div class="box">
								
								<div class="content">
									<form action="ajoutercategorie.php" method="post"> <!-- cadre -->
                        <h1>Créer Catégorie</h1>
     <label class="col-sm-4" for="">Nom Catégorie  </label>
     
                        <input class="form-control col-sm-5 " type="text" name="Nom_cat" placeholder=" Nom " required><br/>
                        

                        

                    

                        <button  name="submit" type="submit" style="color:blue; font-weight:black"onclick>Ajouter</button>
                        <br/><br/>
                    </form>
								</div>
							</div>
						</div>

					</div>
				</div>
			</section>
        <?php include 'basdepage.inc.php';?>
             <script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/jquery.scrollex.min.js"></script>
			<script src="assets/js/skel.min.js"></script>
			<script src="assets/js/util.js"></script>
			<script src="assets/js/main.js"></script>
    </body>
</html>