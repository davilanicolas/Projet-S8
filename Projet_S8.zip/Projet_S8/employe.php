 <!DOCTYPE html>
 <html>
    
    <?php include 'HautDePage.inc.php'?>
    <body>
    <div class="row">    
     <nav class="navbar navbar-expand-md navbar-dark fixed-top bg-dark" data-spy="affix">
         <button class="navbar-toggler d-lg-none" type="button" data-toggle="collapse" data-target="#navbarsExampleDefault" aria-controls="navbarsExampleDefault" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button> 

        <div class="collapse navbar-collapse" id="navbarsExampleDefault">
            
            
<?php include 'divhautdepage.inc.php';?>     
            
        <div class="navbar-collapse collapse w-100 order-1 dual-collapse2">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item">
                    <a class="nav-link" href="modifieretat.php">Modifier etat de la commande <span class="sr-only">(current)</span></a>
                </li>
                
                <li class="nav-item">
                    <a class="nav-link" href="produit.php">Ajouter produit <span class="sr-only">(current)</span></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="index.php">Déconnexion <span class="sr-only">(current)</span></a>
                </li>
            </ul>
        </div>
            
        </div>
     </nav>
    </div> 
        <style>
        img{
           width: 50px;
           height: 50px; 
        }
    </style>

                    <h4>Liste des commandes</h4>

        <div class="table-responsive">
            <table class="table table-striped">
              <thead>
                                                    <tr>
                                                      

                                                        <th>Commande ID</th>
                                                        <th>Produit</th>
                                                        <th>Categorie</th>
                                                        <th>Quantité</th>
                                                        <th>Images</th>
                                                        <th>Client</th>
                                                        <th>Adresse</th>
                                                        <th>Telephone</th>
                                                        <th>Etat</th>
                                                       
                                                        


                                                    </tr>

                                                </thead>
              <tbody>
                
               <?php  $mysqli=mysqli_connect("localhost", "root", "root","sitevitrine"); // Connexion à MySQL
               
                $sql="SELECT commande.QUANTITE, client.ADRESSE, client.CLIENT_NOM, client.CLIENT_PRENOM, client.TELEPHONE, produit.PRODUIT_NOM, produit.CATEGORIE, produit.IMAGES, commande.ETAT, commande.COMMANDE_ID
                      FROM ((commande
                      INNER JOIN client ON commande.CLIENT_ID = client.CLIENT_ID)
                      INNER JOIN produit ON commande.PRODUIT_ID = produit.PRODUIT_ID)";
            
                $req = mysqli_query($mysqli,$sql) or die(mysqli_error($mysqli));?> 
            
            
               <?php while($donnees = mysqli_fetch_assoc($req))
                { ?>
                
                <tr>
                  <td><?php echo $donnees['COMMANDE_ID'];?></td>    
                  <td><?php echo $donnees['PRODUIT_NOM'];?></td>
                  <td><?php echo $donnees['CATEGORIE'];?></td>
                  <td><?php echo $donnees['QUANTITE'];?></td>
                  <td><img src="<?php echo $donnees['IMAGES'];?>"/></td>
                  <td><?php echo $donnees['CLIENT_NOM'];?> <?php echo $donnees['CLIENT_PRENOM'];?></td>
                  <td><?php echo $donnees['ADRESSE'];?></td>
                  <td><?php echo $donnees['TELEPHONE'];?></td>
                  <td><?php echo $donnees['ETAT'];?></td>
                 </tr>
                
                <?php }
                
                
            mysqli_free_result($req);
            mysqli_close($mysqli);   
?>
                
                
              </tbody>
                                            </table>
                                        </div>
            
  </body>
</html>
