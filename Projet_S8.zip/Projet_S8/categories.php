<!DOCTYPE html>
    <html>
      <head>
		<title>First.com</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1" />
		<link rel="stylesheet" href="assets/css/main.css" />
	</head>
        
    <body>
        
     <?php
        // session_login.php

        /* inclusion de la fonction connectMySQL() */
        require_once("connectMySql.inc.php"); // connection a la basse de donnée
       
 
            try {
            $conn = connectMySQL();
           $a=$_GET['id'];
            
    
            $stmt = $conn->query("SELECT * FROM produit WHERE CATEGORIE='$a'");
            session_start();
                                 
        ?>
    
   <?php include 'divhautdepage.inc.php';?>
    
        <section id="One" class="wrapper style3">
				<div class="inner">
					<header class="align-center">
						<h2><?php echo $a;?></h2>
					</header>
				</div>
			</section>
        
      <div id="main" class="container">

				<!-- Elements -->
					<h2 id="elements"><?php echo $a;?></h2>
					<div class="row 200%">

<tbody>

                                                     <?php $i=1;
                                                    while($donnees = $stmt->fetch())
                                                    {

                                                   ?>
                                                    <tr>
                                                        

                                                       <div> 
                                                        <h3><?php echo $donnees['PRODUIT_NOM'];?></h3>
                                                        <ul></ul>
                                                        <td><img src="<?php echo $donnees['IMAGES'];?>"width="250" height="250"></td>
                                                            <ul></ul>
                                                        
                                                            <td>le Prix est de <?php echo $donnees['Prix'];?>€</td>
                                                            <ul></ul>
                                                            <td>Description : <?php echo $donnees['DESCRIPTION'];?></td>

                                                        <ul></ul>
                                                        </div> 
                                                    </tr>
                                                    <?php
                                                        $i=$i +1;
                                                    } //fin de la boucle, le tableau contient toute la
                                                    ?>

                                                </tbody>
         <?php $conn = null;
} catch (PDOException $e) {
    print "Erreur !: " . $e->getMessage() . "<br/>";
    echo $e->getTraceAsString();
    die();
}?>
					</div>

			</div>

 <?php include 'basdepage.inc.php';?>
<!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
 <script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/jquery.scrollex.min.js"></script>
			<script src="assets/js/skel.min.js"></script>
			<script src="assets/js/util.js"></script>
			<script src="assets/js/main.js"></script>

        </body>
    </html>