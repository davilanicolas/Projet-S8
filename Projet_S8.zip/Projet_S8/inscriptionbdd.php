<?php
    session_start();
try
    {
        include ('BDD.php');
    }
    catch(Exception $e)
    {
        die('Erreur : '.$e->getMessage());
    }
    
    if(isset($_REQUEST['submit'])){
        $nom=$_REQUEST['Name'];
        $prenom=$_REQUEST['Prenom'];
        $email=$_REQUEST['email'];
        $mdp=$_REQUEST['mdp'];
        
    
    
    $sql = "INSERT INTO commercial(Nom,prenom,email, mdp) VALUES('$nom','$prenom','$email','$mdp')";
    
    
    mysqli_query($mysqli,$sql) or die(mysqli_error($mysqli));
    
    header( "refresh:1;url=inscription.php" );
    echo "Vous avez crée un nouveau commercial!";
    
    
    
    
    }
?>