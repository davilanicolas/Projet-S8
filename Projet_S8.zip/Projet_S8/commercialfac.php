
<html>
    
 <?php
/*
Page: connexion.php
*/
session_start(); ?>

<!DOCTYPE html>
    <html>
         <head>
		<title>First.com</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1" />
		<link rel="stylesheet" href="assets/css/main.css" />
	</head>
        
        
    <body>
     
     <header id="header" class="alt">
				<div class="logo"><a href="index.php">First</a></div>
				<a href="#menu">Menu</a>
			</header>
            
    <nav id="menu">
				<ul class="links">
					 <li><a href="afficherfactures.php">Liste facture</a></li>
                    <li><a href="commercial.php">Acceuil commercial</a></li>
				</ul>
        <ul>
            <li><a href="index.php">Déconnexion</a></li>
        </ul>
			</nav>    
            
      <section id="One" class="wrapper style3">
				<div class="inner">
					<header class="align-center">
						<h2>Créer facture</h2>
					</header>
				</div>
			</section>
        
        <!-- Conteneur 1 -->
        <section id="one" class="wrapper style2">
				<div class="inner">
					<div class="grid-style">

						<div>
							<div class="box">
								
								<div class="content">
									
<form action="facturesbdd.php" method="post"> <!-- cadre -->
                        <h1>Créer Facture</h1>

                        <!--<label class="col-sm-4" for="DateDevis">Date du devis   </label>
                        <input class="form-control col-sm-5 " type="date" name="Datedevis" placeholder="la date de création " required><br/> -->

                      <select class="form-control col-sm-5 " type="text" name="Client_nom" required>
                                    <option selected>Nom du Client </option>
                                    <?php

                                         require_once("./connectMySql.inc.php");
//pour verifier et si il n'est pas déja placé dans cette matière
try {
    $conn = connectMySQL();

                                         $stmt20 = $conn->query('SELECT * FROM client');

                                        while($donnees = $stmt20->fetch())
                                            {?>
                                                 <option name=Client_nom value="<?php echo $donnees['CLIENT_NOM']?>"><?php echo $donnees['CLIENT_NOM']?>_<?php echo $donnees['CLIENT_PRENOM']?></option>

                                             <?php }

                                           $conn = null;
    } catch (PDOException $e) {
        print "Erreur !: " . $e->getMessage() . "<br/>";
        echo $e->getTraceAsString();
        die();
    }?>

                                </select><br/>
    <select class="form-control col-sm-5 " type="text" name="Client_prenom" required>
                                    <option selected>Prenom du Client </option>
                                    <?php

                                         require_once("./connectMySql.inc.php");
//pour verifier et si il n'est pas déja placé dans cette matière
try {
    $conn = connectMySQL();

                                         $stmt20 = $conn->query('SELECT * FROM client');

                                        while($donnees = $stmt20->fetch())
                                            {?>
                                                 <option name=Client_prenom value="<?php echo $donnees['CLIENT_PRENOM']?>"><?php echo $donnees['CLIENT_PRENOM']?></option>

                                             <?php }

                                           $conn = null;
    } catch (PDOException $e) {
        print "Erreur !: " . $e->getMessage() . "<br/>";
        echo $e->getTraceAsString();
        die();
    }?>

                                </select><br/>
                        
                        <br/>
    <select class="form-control col-sm-5 " type="text" name="Produit_nom" required>
                                    <option selected>Nom du produit </option>
                                    <?php

                                         require_once("./connectMySql.inc.php");
//pour verifier et si il n'est pas déja placé dans cette matière
try {
    $conn = connectMySQL();

                                         $stmt20 = $conn->query('SELECT * FROM produit');

                                        while($donnees = $stmt20->fetch())
                                            {?>
                                                 <option name=Produit_nom value="<?php echo $donnees['PRODUIT_NOM']?>"><?php echo $donnees['PRODUIT_NOM']?></option>

                                             <?php }

                                           $conn = null;
    } catch (PDOException $e) {
        print "Erreur !: " . $e->getMessage() . "<br/>";
        echo $e->getTraceAsString();
        die();
    }?>

                                </select><br/>
                        
                          <label class="col-sm-4" for="Quantité">Quantité   </label>
                        <input class="form-control col-sm-5 " type="text" name="Quantité" placeholder="Quantité" required><br/>
            
                        <label class="col-sm-4" for="Prix">Prix   </label>
                        <input class="form-control col-sm-5 " type="text" name="Prix" placeholder="Prix total" required><br/>
            
                        <!--<label class="col-sm-4" for="DateLivraison">Date de livraison   </label>
                        <input class="form-control col-sm-5 " type="date" name="Datelivraison" placeholder="Date de livraison prévue" required><br/> -->


                        <button  name="submit" type="submit"  style="color:blue; font-weight:black"onclick>crée la facture</button>
                        <br/><br/>
                    </form>
								</div>
							</div>
						</div>

					

					</div>
				</div>
			</section>
            <?php include 'basdepage.inc.php';?>
  <!---------------------------------------------------------------------------->
     <script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/jquery.scrollex.min.js"></script>
			<script src="assets/js/skel.min.js"></script>
			<script src="assets/js/util.js"></script>
			<script src="assets/js/main.js"></script>
                </body>
</html>