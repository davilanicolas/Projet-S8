-- phpMyAdmin SQL Dump
-- version 4.7.3
-- https://www.phpmyadmin.net/
--
-- Hôte : localhost:8889
-- Généré le :  sam. 08 déc. 2018 à 19:48
-- Version du serveur :  5.6.35
-- Version de PHP :  7.1.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `sitevitrine`
--

-- --------------------------------------------------------

--
-- Structure de la table `categories`
--

CREATE TABLE `categories` (
  `CATEGORIES_ID` int(100) NOT NULL,
  `CATEGORIES` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `categories`
--

INSERT INTO `categories` (`CATEGORIES_ID`, `CATEGORIES`) VALUES
(1, 'Figurines'),
(3, 'JeuxVideo'),
(4, 'sac'),
(7, 'tasse'),
(2, 'Vetements');

-- --------------------------------------------------------

--
-- Structure de la table `client`
--

CREATE TABLE `client` (
  `CLIENT_ID` int(11) NOT NULL,
  `CLIENT_NOM` varchar(20) NOT NULL,
  `CLIENT_PRENOM` varchar(20) NOT NULL,
  `ADRESSE` varchar(50) NOT NULL,
  `TELEPHONE` int(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `client`
--

INSERT INTO `client` (`CLIENT_ID`, `CLIENT_NOM`, `CLIENT_PRENOM`, `ADRESSE`, `TELEPHONE`) VALUES
(1, 'N', 'A', '1 rue A', 707060602),
(4, 'LEROY', 'Francois', '175 Avenue de la paix 91000', 102010201),
(3, 'B', 'C', '1 rue B', 708090102),
(5, 'SALAH', 'Mohamed', '153 Boulevard de l\'Europe', 760482951),
(6, 'o', 'k', '120 salut', 757124356);

-- --------------------------------------------------------

--
-- Structure de la table `commande`
--

CREATE TABLE `commande` (
  `COMMANDE_ID` int(11) NOT NULL,
  `PRODUIT_ID` int(11) NOT NULL,
  `QUANTITE` int(11) DEFAULT NULL,
  `CLIENT_ID` int(11) NOT NULL,
  `ETAT` varchar(50) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL DEFAULT 'non fait'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `commande`
--

INSERT INTO `commande` (`COMMANDE_ID`, `PRODUIT_ID`, `QUANTITE`, `CLIENT_ID`, `ETAT`) VALUES
(1, 1, 5, 1, 'non fait'),
(2, 2, 2, 3, 'non fait'),
(3, 5, 3, 4, 'non fait'),
(4, 4, 1, 5, 'non fait'),
(5, 11, 20, 0, 'non fait'),
(6, 11, 20, 0, 'non fait'),
(7, 11, 20, 0, 'non fait'),
(8, 11, 20, 0, 'non fait'),
(9, 11, 20, 0, 'non fait'),
(10, 11, 20, 0, 'non fait'),
(11, 11, 20, 0, 'non fait'),
(12, 1, 20, 0, 'non fait'),
(13, 1, 20, 0, 'non fait'),
(14, 1, 20, 3, 'non fait'),
(15, 0, 10, 0, 'non fait'),
(16, 0, 10, 0, 'non fait'),
(17, 0, 10, 4, 'non fait'),
(18, 6, 10, 4, 'non fait'),
(19, 7, 10, 4, 'non fait'),
(20, 47, 5, 4, 'non fait'),
(21, 21, 11, 4, 'non fait'),
(22, 54, 20, 4, 'fait'),
(23, 54, 25, 4, 'non fait'),
(24, 0, 25, 1, 'non fait');

-- --------------------------------------------------------

--
-- Structure de la table `commercial`
--

CREATE TABLE `commercial` (
  `Nom` varchar(20) NOT NULL,
  `prenom` varchar(20) NOT NULL,
  `email` text NOT NULL,
  `mdp` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `commercial`
--

INSERT INTO `commercial` (`Nom`, `prenom`, `email`, `mdp`) VALUES
('davila', 'nicolas', 'davilanicolas@hotmail.fr', 'a'),
('salut', 'nn', 'nico97160@hotmail.fr', 'ab'),
('salut', 'nn', 'nico97160@hotmail.fr', 'ab'),
('salut', 'nn', 'ab@hotmail.fr', 'aa'),
('cn', 'bcnozs', 'ab@hotmail.abc', 'aa'),
('a', 'a', 'ab@hotmail.fr', 'a');

-- --------------------------------------------------------

--
-- Structure de la table `devis`
--

CREATE TABLE `devis` (
  `DEVIS_ID` int(11) NOT NULL,
  `DATE` date NOT NULL,
  `CLIENT_ID` int(11) NOT NULL,
  `PRODUIT_ID` int(11) NOT NULL,
  `QUANTITE` int(11) NOT NULL,
  `PRIX` int(11) NOT NULL,
  `COMMENTAIRES` varchar(50) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `devis`
--

INSERT INTO `devis` (`DEVIS_ID`, `DATE`, `CLIENT_ID`, `PRODUIT_ID`, `QUANTITE`, `PRIX`, `COMMENTAIRES`) VALUES
(27, '0000-00-00', 0, 45, 12, 4, ''),
(26, '0000-00-00', 4, 47, 3, 100, '');

-- --------------------------------------------------------

--
-- Structure de la table `facture`
--

CREATE TABLE `facture` (
  `produit` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `image`
--

CREATE TABLE `image` (
  `IMAGES` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `image`
--

INSERT INTO `image` (`IMAGES`) VALUES
('a.jpg'),
('6f72bc6e-f203-4be3-88b3-7c4dddebe5d0.mp4'),
('6f72bc6e-f203-4be3-88b3-7c4dddebe5d0.mp4'),
('IMG_9531.JPG'),
('sangoku.jpg'),
('fond2.jpg');

-- --------------------------------------------------------

--
-- Structure de la table `produit`
--

CREATE TABLE `produit` (
  `PRODUIT_ID` int(11) NOT NULL,
  `PRODUIT_NOM` varchar(40) CHARACTER SET utf8 NOT NULL,
  `CATEGORIE` varchar(20) CHARACTER SET utf8 NOT NULL,
  `IMAGES` varchar(50) CHARACTER SET utf8 NOT NULL,
  `DESCRIPTION` varchar(250) CHARACTER SET utf8 NOT NULL,
  `Prix` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `produit`
--

INSERT INTO `produit` (`PRODUIT_ID`, `PRODUIT_NOM`, `CATEGORIE`, `IMAGES`, `DESCRIPTION`, `Prix`) VALUES
(2, 'Batman', 'Figurines', 'IMAGES/Figurines/batman.jpg', 'la figurine de Batman', 25),
(45, 'Chevalier Rouge', 'Figurines', 'IMAGES/Figurines/fortnite.jpg', 'Figurine du chevalier', 34),
(46, 'DragonballZ', 'JeuxVideo', 'IMAGES/JeuxVideo/dragonballz.jpg', 'Dragon Fighter Z', 50),
(49, 'tassedbz', 'tasse', 'IMAGES/tassedbz.jpg', 'tasse de sangoku', 20),
(50, 'Fortnite', 'JeuxVideo', 'IMAGES/JeuxVideo/fortnite.jpg', 'le jeux vidéo le plus tendance du moment', 25),
(3, 'Pack de figurine marvel', 'Figurines', 'IMAGES/Figurines/marvel.jpg', 'Figurines de iron man, captain america et thor', 60),
(54, 'tshirtdbz', 'Vetements', 'IMAGES/Vetements/tshirtdbz.jpg', 't-shirt dragon ball super de sangoku', 28),
(53, 'bijour', 'bonjour', 'IMAGES/bonjour.jpeg', 'bonjour', 10),
(5, 'sacdbz', 'sac', 'IMAGES/sacdbz.jpg', 'sac enfant dragon ball', 25);

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`CATEGORIES_ID`),
  ADD KEY `CATEGORIE` (`CATEGORIES`);

--
-- Index pour la table `client`
--
ALTER TABLE `client`
  ADD PRIMARY KEY (`CLIENT_ID`),
  ADD UNIQUE KEY `CLIENT_ID` (`CLIENT_ID`);

--
-- Index pour la table `commande`
--
ALTER TABLE `commande`
  ADD PRIMARY KEY (`COMMANDE_ID`),
  ADD KEY `FK2_PRODUIT_ID` (`PRODUIT_ID`),
  ADD KEY `CLIENT_ID` (`CLIENT_ID`);

--
-- Index pour la table `devis`
--
ALTER TABLE `devis`
  ADD PRIMARY KEY (`DEVIS_ID`),
  ADD KEY `FK_CLIENT_ID` (`CLIENT_ID`),
  ADD KEY `FK_PRODUIT_ID` (`PRODUIT_ID`);

--
-- Index pour la table `produit`
--
ALTER TABLE `produit`
  ADD PRIMARY KEY (`PRODUIT_ID`),
  ADD KEY `CATEGORIE` (`CATEGORIE`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `categories`
--
ALTER TABLE `categories`
  MODIFY `CATEGORIES_ID` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT pour la table `client`
--
ALTER TABLE `client`
  MODIFY `CLIENT_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT pour la table `commande`
--
ALTER TABLE `commande`
  MODIFY `COMMANDE_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;
--
-- AUTO_INCREMENT pour la table `devis`
--
ALTER TABLE `devis`
  MODIFY `DEVIS_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;
--
-- AUTO_INCREMENT pour la table `produit`
--
ALTER TABLE `produit`
  MODIFY `PRODUIT_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=57;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
