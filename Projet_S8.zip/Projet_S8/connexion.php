<?php
/*
Page: connexion.php
*/
session_start(); ?>

<!DOCTYPE html>
    <html>
         <head>
		<title>First.com</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1" />
		<link rel="stylesheet" href="assets/css/main.css" />
	</head>
        
        
    <body>
     
     
            
    <?php include 'divhautdepage.inc.php';?>      
            
      <section id="One" class="wrapper style3">
				<div class="inner">
					<header class="align-center">
						<h2>Connexion</h2>
					</header>
				</div>
			</section>


 <form class="container text-center" action="connexionbdd.php" method="post">
  <div class="form-group">
    <label for="email">Adresse E-mail</label>
    <input type="email" class="form-control" id="email" name="email" aria-describedby="emailHelp" placeholder="Enter email" required>
    
  </div>
  <div class="form-group">
    <label for="mdp">Mot de passe</label>
    <input type="password" class="form-control" id="mdp" name="mdp" placeholder="Password" required>
  </div>

  <button type="submit" name="submit" class="btn btn-secondary">Se Connecter</button>
     
     
</form> 
        <?php include 'basdepage.inc.php';?>
<!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
 <script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/jquery.scrollex.min.js"></script>
			<script src="assets/js/skel.min.js"></script>
			<script src="assets/js/util.js"></script>
			<script src="assets/js/main.js"></script>

        </body>
    </html>