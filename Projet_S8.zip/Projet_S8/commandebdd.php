<?php
    session_start();
try
    {
        include ('BDD.php');
    }
    catch(Exception $e)
    {
        die('Erreur : '.$e->getMessage());
    }
    
    if(isset($_REQUEST['submit'])){
        
        $produit_nom=$_REQUEST['Produit_nom'];
        $client_nom=$_REQUEST['Clientnom'];
        $client_prenom=$_REQUEST['Clientprenom'];
        $quantite=$_REQUEST['Quantite'];
        
    
    $id=mysqli_query($mysqli,"SELECT PRODUIT_ID FROM produit WHERE PRODUIT_NOM='$produit_nom'");
    $id2=mysqli_query($mysqli,"SELECT CLIENT_ID FROM client WHERE CLIENT_NOM='$client_nom' AND CLIENT_PRENOM='$client_prenom'");
        
        $donn=$id->fetch_assoc();
        $donn2=$id2->fetch_assoc();
    
        $insert= $donn['PRODUIT_ID'];
        $insertt= $donn2['CLIENT_ID'];
        
    $sql1= "INSERT INTO commande(QUANTITE,PRODUIT_ID,CLIENT_ID) VALUES('$quantite','$insert','$insertt')";
    
   
    
    
    mysqli_query($mysqli,$sql1) or die(mysqli_error($mysqli));
    
    header( "refresh:0;url=employe.php" );
    echo 'Commande créée avec succès!';
    
    
    
    
    }
?>