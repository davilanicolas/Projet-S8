<?php
// on se connecte à notre base
session_start();
try
    {
        include ('BDD.php');
    }
    catch(Exception $e)
    {
        die('Erreur : '.$e->getMessage());
    }
 $cat_id=$_POST["Cat_ID"];
 $nom_cat=$_POST["Nom_cat"];

 
 $sql = "INSERT INTO categories(CATEGORIES) VALUES('$nom_cat')";
	
 $requete = mysqli_query($mysqli,$sql) or die(mysqli_error($mysqli));
	 if($requete)
  {
    echo("catégorie ajoutée") ;
  }
  else
  {
    echo("L'insertion à échouée") ;
  }

	

	

	

?>