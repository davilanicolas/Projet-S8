<header id="header" class="alt">
				<div class="logo"><a href="index.php">First</a></div>
				<a href="index.php">Retour</a>
			</header>

		<!-- Nav -->
			<nav id="menu">
				<ul class="links">
					              <?php

                                         require_once("./connectMySql.inc.php");
//pour verifier et si il n'est pas déja placé dans cette matière
try {
    $conn = connectMySQL();

                                         $stmt20 = $conn->query('SELECT * FROM categories ');

                                        while($donnees = $stmt20->fetch())
                                            {?>
                <li class="nav-item">
                                                 <a href="categories.php?id=<?php echo $donnees['CATEGORIES']?>"><?php echo $donnees['CATEGORIES']?></a>
                    
            </li>

                                             <?php }
    
                                           $conn = null;
    } catch (PDOException $e) {
        print "Erreur !: " . $e->getMessage() . "<br/>";
        echo $e->getTraceAsString();
        die();
    }?>
                

                              
                
				</ul>
			</nav>