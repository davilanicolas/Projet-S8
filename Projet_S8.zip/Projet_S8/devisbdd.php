<?php
    session_start();
try
    {
        include ('BDD.php');
    }
    catch(Exception $e)
    {
        die('Erreur : '.$e->getMessage());
    }
    
    if(isset($_REQUEST['submit'])){
        
        $client_nom=$_REQUEST['Clientnom'];
        $client_prenom=$_REQUEST['Clientprenom'];
        $produit_nom=$_POST['Produit_nom'];
        $quantite=$_REQUEST['Quantité'];
        $prix=$_REQUEST['Prix'];
        $commentaires=$_REQUEST['Commentaire'];
    
   
    $id=mysqli_query($mysqli,"SELECT PRODUIT_ID FROM produit WHERE PRODUIT_NOM='$produit_nom'");
    $id2=mysqli_query($mysqli,"SELECT CLIENT_ID FROM client WHERE CLIENT_NOM='$client_nom' AND CLIENT_PRENOM='$client_prenom'");
        
        $donn=$id->fetch_assoc();
        $donn2=$id2->fetch_assoc();
    
        $insert= $donn['PRODUIT_ID'];
        $insertt= $donn2['CLIENT_ID'];    
        
    $sql = "INSERT INTO devis (DEVIS_ID, CLIENT_ID, PRODUIT_ID, QUANTITE, PRIX, COMMENTAIRES ) VALUES('$devis_id','$insertt','$insert','$quantite','$prix','$commentaires')";
    
    
    mysqli_query($mysqli,$sql) or die(mysqli_error($mysqli));
    
    header( "refresh:3;url=commercial.php" );
    echo 'Devis crée avec succès!';
    
    
    
    
    }
?>