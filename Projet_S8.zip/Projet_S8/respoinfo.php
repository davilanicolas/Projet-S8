<!DOCTYPE html>

<html>
    
    <?php include 'HautDePage.inc.php'?>
    <body>
    <div class="row">    
     <nav class="navbar navbar-expand-md navbar-dark fixed-top bg-dark" data-spy="affix">
         <button class="navbar-toggler d-lg-none" type="button" data-toggle="collapse" data-target="#navbarsExampleDefault" aria-controls="navbarsExampleDefault" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button> 

        <div class="collapse navbar-collapse" id="navbarsExampleDefault">
            
            
            
    <?php include 'divhautdepage.inc.php';?>     
            
        <div class="navbar-collapse collapse w-100 order-3 dual-collapse2">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item">
                    <a class="nav-link" href="listeclient.php">Liste clients <span class="sr-only">(current)</span></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="produit.php">Produit <span class="sr-only">(current)</span></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="afficherdevis.php">Devis <span class="sr-only">(current)</span></a>
                </li>
                
                <li class="nav-item">
                    <a class="nav-link" href="afficherfactures.php">Factures <span class="sr-only">(current)</span></a>
                </li>
                
                <li class="nav-item">
                    <a class="nav-link" href="commande.php">Commande <span class="sr-only">(current)</span></a>
                </li>
                
                <li class="nav-item">
                    <a class="nav-link" href="index.php">Déconnexion <span class="sr-only">(current)</span></a>
                </li>
            </ul>
        </div>
            
        </div>
     </nav>
    </div> 
        <h3> Client</h3>
            <ul class="nav-item">
                    <a class="nav-link" href="listeclient.php">Liste client <span class="sr-only">(current)</span></a>
                
        
                    <a class="nav-link" href="client.php">Crée client <span class="sr-only">(current)</span></a>
                </ul>
            
        <h3> Produit</h3>
            <ul class="nav-item">
                    <a class="nav-link" href="afficherproduit.php">Liste produit <span class="sr-only">(current)</span></a>
                
        
                    <a class="nav-link" href="produit.php">Crée Produit <span class="sr-only">(current)</span></a>
                </ul>

    <h3> Devis</h3>
            <ul class="nav-item">
                    <a class="nav-link" href="afficherdevis.php">Liste Devis <span class="sr-only">(current)</span></a>
                </ul>
                
    <h3> Commande</h3>
            <ul class="nav-item">
                    <a class="nav-link" href="commande.php">Liste commandes <span class="sr-only">(current)</span></a>
                </ul>
    </body>
</html>
